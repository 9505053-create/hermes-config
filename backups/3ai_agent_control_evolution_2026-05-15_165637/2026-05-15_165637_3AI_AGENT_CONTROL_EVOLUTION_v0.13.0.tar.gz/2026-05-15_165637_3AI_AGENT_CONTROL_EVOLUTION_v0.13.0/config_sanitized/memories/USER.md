All detailed user preferences, red lines, and operational guidelines are now stored in /home/chien/USER_PROFILE.md. Refer to this file for all user-specific constraints.
§
User prefers that the agent performs background research and prepares optimization proposals during work hours, delaying complex setups or requests for user action until after work.
§
User provides educational resources (like YouTube videos) to drive the agent's self-evolution and expects the agent to actively synthesize these insights into its operational logic and skill set.
§
Scott 的絕對禁令 (絕對不可違反)：
1. 財務安全：嚴禁私自使用用戶信用卡進行任何購物或消費。
2. 數據安全：在執行大量刪除檔案操作前，必須獲得用戶明確確認。
3. 隱私安全：未經許可，嚴禁將帳號、密碼等任何敏感資訊傳送給第三方。
§
Telegram Output Sanitizer: 嚴禁在一般說明文字中使用 LaTeX ($, \rightarrow, \approx 等)。箭頭改用 -> 或 →，約略用 「約」或 ≈。絕對保護區域：Code blocks, 路徑 (C:\Users\...), JSON, YAML, regex。送出前必掃描非代碼區塊並改寫。
§
User shortcut 'gc@': Trigger to initiate the 'skill-engineering' workflow.
§
User adopts a 'Refinery and Driver' architecture for AI agents: using Hermes as a 'Refinery' for rapid skill iteration and evolution, and OpenClaw as the 'Driver' for stable, production-grade execution.
§
User is implementing the LLM-Wiki methodology (atomic, linked Markdown files) to build and manage their personal knowledge base.
§
User is a ChatGPT paid subscriber and has the Codex CLI installed on their Windows host.
§
User's Google Drive Hermes Workspace:
- Folder Path: 我的雲端硬碟 > AI WorkSpace > Hermes
- Folder ID: 1F6ZL7mX_gyxj9V4ylHVpyoZAK6b7gztd
- Link: https://drive.google.com/drive/folders/1F6ZL7mX_gyxj9V4ylHVpyoZAK6b7gztd
- Purpose: Designated workspace for Hermes to store files
- Usage: Upload reports, backups, exports, and other files here
§
User's 3AI CLI Subscriptions (Monthly):
- Claude CLI: Monthly subscription (Anthropic)
- CODEX CLI: Monthly subscription (OpenAI)
- Gemini CLI: Monthly subscription (Google)

User's Token Cost Concern: [REDACTED]
- Hermes uses OpenRouter API tokens (costs money to purchase)
- 3AI CLIs use monthly subscriptions (fixed cost, usage limits)

User's Core Directive:
- Hermes should be a smart "Commander" that strategically uses 3AI resources
- Simple tasks: Hermes does them
- Complex tasks: Delegate to 3AI first, then Hermes summarizes and executes
- Goal: Save Hermes tokens (which cost money) by using subscription resources

User's Expectations:
- Don't make user re-explain 3AI concepts in new conversation windows
- Dynamically manage token usage (consolidate long conversations)
- Update Supabase database when adding new skills
- Maintain memory continuity across sessions
