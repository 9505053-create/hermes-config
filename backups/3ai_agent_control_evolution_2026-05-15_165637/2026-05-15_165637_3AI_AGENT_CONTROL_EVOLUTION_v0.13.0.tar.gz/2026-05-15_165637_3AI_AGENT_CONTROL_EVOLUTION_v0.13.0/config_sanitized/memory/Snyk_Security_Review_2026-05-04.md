# Snyk Agent Scan 安全改善記錄
日期：2026-05-04

## 掃描結果
- 掃描 6 個 top-level skill
- 2 個無問題：code-review-implementation, token-memory-manager
- 4 個高風險：google-drive-crud(W011), 3ai-commander(W008), hermes-integrations(W011), dogfood(W011)

## 已執行修復

### P1：W008 Folder ID 外洩 → 已修復
- 7 處 Folder ID 從 SKILL.md 移除
- 改存入 `~/.hermes/.env` 為 `HERMES_GDRIVE_WORKSPACE_FOLDER_ID`
- SKILL.md 改引用 `${HERMES_GDRIVE_WORKSPACE_FOLDER_ID}`
- 受影響檔案：google-drive-crud, hermes-integrations, 3ai-commander

### P0：全域信任邊界規則 → 已建立
- 檔案：`~/.hermes/SECURITY_TRUST_BOUNDARY.md`
- 內容：信任層級定義、外部內容隔離包裝格式、敏感動作確認規則、掃描觸發時機

## 顧問團共識（GPT/Claude/Gemini 三方一致）
1. W011 是結構性風險，無法「修掉」只能架構隔離
2. 外部內容用 `<<< EXTERNAL_CONTENT_START >>>` 隔離包裝
3. 雙層信任模型：Tier1 高信任可執行 / Tier2 低信任只當資料
4. 掃描應改為事件觸發而非每月固定
5. dogfood 風險最高（任意 URL 內容最不可控）

## 待處理（需 Scott 決定）
- google-drive-crud OAuth scope 是否改為 read-only
- dogfood 是否加 URL 安全閘門（預覽前確認 URL）
- hermes-integrations 是否禁止自動執行 repo 內 script

## Snyk Token
- 帳號：9505053@gmail.com
- Token 到期：2026-08-02
- 6 月底需 rollover
