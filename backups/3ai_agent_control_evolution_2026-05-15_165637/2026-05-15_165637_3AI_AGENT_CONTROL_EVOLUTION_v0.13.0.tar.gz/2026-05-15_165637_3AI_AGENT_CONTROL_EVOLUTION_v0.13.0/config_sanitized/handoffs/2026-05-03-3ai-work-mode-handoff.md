# 3AI Work Mode Handoff - 2026-05-03

## User Identity
- **Name**: Scott
- **Telegram**: Connected
- **Language**: 繁體中文
- **Contact**: 9505053@gmail.com

## 3AI Work Mode Established
- **Date**: 2026-05-03
- **Status**: Active
- **Permission**: 100% authorized to operate Claude, CODEX, Gemini CLI

## 3AI CLI Tools (User's Monthly Subscriptions)
1. **Claude CLI** (Anthropic)
   - Path: `C:\Users\chien\AppData\Roaming\npm\claude.cmd`
   - Model: Claude Sonnet 4.6
   - Command: `/mnt/c/Windows/System32/cmd.exe /c "cd /d C:\Users\chien && C:\Users\chien\AppData\Roaming\npm\claude.cmd -p \"Your question\""`

2. **CODEX CLI** (OpenAI)
   - Path: `C:\Users\chien\AppData\Roaming\npm\codex.cmd`
   - Model: GPT-5.5
   - Command: `/mnt/c/Windows/System32/cmd.exe /c "cd /d C:\Users\chien && C:\Users\chien\AppData\Roaming\npm\codex.cmd exec --skip-git-repo-check Your question"`

3. **Gemini CLI** (Google)
   - Path: `C:\Users\chien\AppData\Roaming\npm\gemini.cmd`
   - Model: Gemini 3.1 Pro Preview
   - Command: `/mnt/c/Windows/System32/cmd.exe /c "cd /d C:\Users\chien && C:\Users\chien\AppData\Roaming\npm\gemini.cmd \"Your question\""`

## Hermes Configuration
- **Model**: Xiaomi MiMo v2 Pro (via OpenRouter)
- **Cost**: API tokens (purchased separately)
- **Role**: Commander - strategically uses 3AI resources
- **Google Drive Workspace**: `AI WorkSpace > Hermes` (ID: 1F6ZL7mX_gyxj9V4ylHVpyoZAK6b7gztd)

## Task Allocation Strategy
- **Simple tasks**: Execute with Hermes
- **Complex tasks**: Delegate to 3AI first, then summarize and execute
- **Goal**: Save Hermes tokens by using subscription resources

## Key Files Updated
1. `/home/chien/.hermes/memories/MEMORY.md` — Added 3AI Work Mode section
2. `/home/chien/.hermes/memories/USER.md` — Added 3AI subscriptions and directives
3. `/home/chien/.hermes/skills/3ai-commander/SKILL.md` — New skill for 3AI coordination
4. `/home/chien/.hermes/skills/token-memory-manager/SKILL.md` — New skill for token management
5. `/home/chien/.hermes/skills/hermes-integrations/SKILL.md` — Complete integration guide
6. `/home/chien/.hermes/skills/code-review-implementation/SKILL.md` — Process external review feedback
7. `/home/chien/.hermes/memories/SUPABASE_EXTERNAL_BRAIN_INDEX.md` — Updated with new skills

## Supabase Status
- **Database**: 71 rows in hermes_knowledge (up from 69)
- **New modules**: RECOVERY (2 rows from 2026-05-01)
- **Connection**: `docker exec -u postgres supabase-db psql -d postgres`

## Pending Items
- Update Supabase with new skills (3ai-commander, token-memory-manager, hermes-integrations)
- Test 3AI collaboration on a real task
- Configure automatic Supabase updates for new skills

## Available Integrations (Ready to Use)
- ✅ **GitHub** — git + curl (gh CLI not installed)
- ✅ **Email** — Gmail SMTP (credentials configured)
- ✅ **Google Workspace** — OAuth authenticated (Gmail, Calendar, Drive, Sheets, Docs, Contacts)
- ✅ **Notion** — API key configured
- ✅ **3AI CLIs** — Claude, CODEX, Gemini (user's monthly subscriptions)
- ✅ **Local Supabase** — Docker container running
- ✅ **Google Drive Workspace** — `AI WorkSpace > Hermes` (ID: 1F6ZL7mX_gyxj9V4ylHVpyoZAK6b7gztd)

## Integration Reference
For complete integration documentation, load skill: `hermes-integrations`

## 3AI 調用經驗 (2026-05-03 更新)

### 遇到的問題
1. **中文與特殊字元** — 命令被截斷、語法錯誤
2. **訊息過長** — CLI 非互動模式有字元限制
3. **逾時** — 複雜問題需要更長時間
4. **檔案存取限制** — WSL CLI 無法直接存取 Windows 檔案系統

### 解決方案
1. **極簡問題** — 1-3 個英文單字
2. **避免特殊字元** — 無問號、引號、箭頭
3. **命令式語句** — 而非完整問句
4. **增加逾時** — 設定 60 秒 timeout
5. **選擇合適 CLI** — Claude 適合解釋、CODEX 適合驗證、Gemini 適合分析
6. **接受限制** — 複雜問題可能需要本地處理

### 測試結果
- ✅ Claude: "Hello" 正常回應
- ✅ CODEX: "Hello" 正常回應  
- ✅ Gemini: "Done" 正常回應
- ❌ Claude: 複雜問題被截斷
- ❌ CODEX: 空格造成語法錯誤
- ❌ Gemini: 長問題逾時
- ⚠️ 檔案存取: 無法直接讀取 WSL 路徑

### 實際工作流程
1. **先測試可用性** — 用 "Hello" 確認 CLI 可用
2. **極簡問題** — 1-2 個單字最穩定
3. **複雜問題本地處理** — 接受 CLI 限制
4. **記錄經驗** — 持續優化調用模式

### 技能更新
- `3ai-commander` 已更新，包含實際測試結果
- 記錄了成功和失敗模式
- 建立了實用的工作流程

## User's Core Expectations
1. **Don't re-explain** 3AI concepts in new sessions
2. **Dynamically manage** token usage
3. **Update Supabase** when adding new skills
4. **Maintain memory continuity** across sessions
5. **Be a smart Commander** — strategically use 3AI resources
6. **User gives tasks directly** — no need to say "3AI"
7. **Hermes decides** when to use 3AI — proactive delegation

## Next Steps
1. Test 3AI collaboration on a complex task
2. Set up automatic Supabase sync for new skills
3. Configure token monitoring and alerts
4. Create workflow for conversation consolidation

---

**This handoff file ensures that in future sessions, the agent immediately understands the 3AI work mode, user's subscriptions, and strategic directives without requiring re-explanation.**
