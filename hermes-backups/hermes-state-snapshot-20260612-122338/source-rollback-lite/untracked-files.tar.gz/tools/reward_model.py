
import json
import logging
from typing import Any, Dict, List, Tuple, Optional

logger = logging.getLogger(__name__)

class RewardModel:
    """
    Intrinsic Reward Model for self-evaluating agent trajectories.
    Implements a relative scoring system inspired by GRPO.
    """
    
    def __init__(self):
        # Weights for different reward dimensions
        self.weights = {
            "efficiency": 0.3,
            "precision": 0.4,
            "robustness": 0.2,
            "consistency": 0.1,
        }

    def evaluate_trajectory(self, trajectory: Dict[str, Any]) -> Dict[str, Any]:
        """
        Evaluate a single trajectory and return detailed scores.
        
        Args:
            trajectory: A dictionary containing messages and metadata.
        """
        # 1. Efficiency: Negative reward for redundant tool calls
        tool_calls = [m for m in trajectory.get("messages", []) if m.get("role") == "assistant" and m.get("tool_calls")]
        num_calls = sum(len(tc["tool_calls"]) for tc in tool_calls)
        efficiency_score = max(0, 10 - (num_calls // 2)) # Simple decay
        
        # 2. Precision: High reward for getting it right in few turns
        # (In a real scenario, this would check against a ground truth or final_response)
        precision_score = 10 if trajectory.get("completed") else 0
        
        # 3. Robustness: Reward for mentions of edge cases in <think> blocks
        thinking_content = " ".join([m.get("reasoning", "") for m in trajectory.get("messages", []) if m.get("reasoning")])
        robustness_score = 10 if any(word in thinking_content.lower() for word in ["edge case", "exception", "error", "failure", "fallback"]) else 5
        
        # 4. Consistency: Reward for structured reasoning (e.g., using the HRP protocol)
        consistency_score = 10 if "Step" in thinking_content or "Deconstruction" in thinking_content else 5
        
        weighted_score = (
            efficiency_score * self.weights["efficiency"] +
            precision_score * self.weights["precision"] +
            robustness_score * self.weights["robustness"] +
            consistency_score * self.weights["consistency"]
        )
        
        return {
            "total_score": weighted_score,
            "dimensions": {
                "efficiency": efficiency_score,
                "precision": precision_score,
                "robustness": robustness_score,
                "consistency": consistency_score,
            },
            "status": "high_quality" if weighted_score > 7 else "average" if weighted_score > 4 else "low_quality"
        }

    def compute_relative_rewards(self, group: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Compute relative rewards for a group of trajectories (GRPO style).
        """
        if not group: return []
        
        scores = [self.evaluate_trajectory(t)["total_score"] for t in group]
        mean_score = sum(scores) / len(scores)
        
        results = []
        for i, traj in enumerate(group):
            relative_reward = scores[i] - mean_score
            results.append({
                "trajectory_id": i,
                "absolute_score": scores[i],
                "relative_reward": relative_reward,
                "is_gold": relative_reward > 0
            })
            
        return results

# Singleton
reward_model = RewardModel()

def evaluate_trajectory(trajectory: Dict[str, Any]) -> Dict[str, Any]:
    return reward_model.evaluate_trajectory(trajectory)

def compute_group_rewards(group: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return reward_model.compute_relative_rewards(group)
