# 3AI CLI Disk I/O Rule — WINDOWS MODE

Date: 2026-05-12

Scott instruction: whenever a task needs 3AI CLI disk read/write, mark and run it as **WINDOWS MODE**, not WSL mode, to avoid false negatives.

## Rule

- Required label: `WINDOWS MODE`
- Workspace: `C:\Users\chien\_3AI_WorkSpace`
- Do not conclude 3AI CLI cannot write disk based on WSL-mode failures.
- Always verify actual file creation by reading back the output file.

## Working commands

```bat
Claude: cmd.exe /c "cd /d C:\Users\chien\_3AI_WorkSpace && type prompt.txt | claude.cmd --print --allowedTools Bash Write Edit"
Codex:  cmd.exe /c "cd /d C:\Users\chien\_3AI_WorkSpace && type prompt.txt | codex.cmd exec --skip-git-repo-check --sandbox workspace-write"
Gemini: cmd.exe /c "cd /d C:\Users\chien\_3AI_WorkSpace && type prompt.txt | gemini.cmd --skip-trust --approval-mode yolo"
```

## Skill

Canonical reusable skill: `3ai-windows-mode-disk-io`
