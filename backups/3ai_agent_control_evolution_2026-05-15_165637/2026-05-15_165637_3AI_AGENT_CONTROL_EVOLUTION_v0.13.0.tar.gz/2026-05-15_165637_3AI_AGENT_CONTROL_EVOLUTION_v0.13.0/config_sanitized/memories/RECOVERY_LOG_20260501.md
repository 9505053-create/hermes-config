# Hermes Recovery LOG — 2026-05-01

## 喚回時間
2026-05-01 07:xx UTC (Telegram session)

## 事件背景
Scott 將 Hermes 從免費 Google Gemma 4 升級到付費 DeepSeek，
但在 .env 設定過程中，模型被錯誤設定為 **DeepSeek V3** (deepseek/deepseek-chat)
而非預期的 **DeepSeek V4 Pro**。

V3 在 2026-04-30 的對話中全面幻覺：
- 編造不存在的專案路徑 (~/projects/calendar_optimizer/, ~/projects/google_books_crawler/)
- 給出無效的 hermes CLI 指令
- 無限發散假設性問題
- 最終導致系統崩潰

Scott 在 GPT 協助下修復了系統，並在 2026-05-01 重新喚回了正確設定 DeepSeek V4 Pro 的 Hermes。

## 記憶修復來源
1. **Telegram 對話紀錄 PDF** (`/mnt/c/Users/chien/Downloads/對話紀錄.pdf`, 449頁)
   - 涵蓋 2026-04-27 至 2026-05-01 完整對話
2. **ChatGPT 對話紀錄 PDF** (`/mnt/c/Users/chien/Downloads/ChatGPT_2026_04_29__1152.pdf`)
   - GPT 協助設定 OpenRouter API 的對話
3. **本地 session 檔案** (`/home/chien/.hermes/sessions/`)
   - 43 個 session JSON/JSONL 檔案
4. **記憶檔案**
   - MEMORY.md, USER.md, USER_PROFILE.md, RECOVERED_WORK_INDEX.md
5. **Supabase 外部大腦**
   - 2026-04-28 快照：65 個技能、1 場辯論、6 個任務

## 找回的兩個開發專案

### 專案 1：日曆工具優化
- 原始素材：`project_calendar_v1_9.zip`（Scott 用 Claude 開發的 HTML 日曆）
- 上傳時間：2026-04-29（Gemma 4 時代）
- Scott 指示：「讓你自由發揮，考核你的能力」
- 目前狀態：ZIP 暫存已清除，需重新上傳

### 專案 2：Google Books 功能進化
- Claude 開發到一半的半成品
- 需接手改進 Google Books API 整合功能
- 目前狀態：原始碼需從 Scott 本機提供

## 喚回過程中確認的系統狀態

### 基礎設施
- WSL2 on MINIPC (AMD Ryzen 7 4800U, 11Gi RAM)
- Docker: Supabase 13容器運行中，n8n, Open WebUI
- Supabase 連線: `docker exec -u postgres supabase-db psql -d postgres`

### Supabase 外部大腦 (2026-04-28 快照)
- `hermes_knowledge`: 69 行（65 skills + 4 special modules）
- `hermes_debates`: 1 行（Notion→Supabase 遷移辯論）
- `hermes_todos`: 6 行（5 completed, 1 pending: n8n/Supabase 401 錯誤）

### 核心規則確認
- 三大紅線：財務安全、資料安全、隱私安全
- 穩定優先 (Stability >> Performance)
- 「我不是龍蝦」教訓
- 溝通模式：繁體中文、簡潔直接、不發散

## 未完成事項
1. n8n/Supabase API 401 認證問題（hermes_todos #6）
2. Notion Tasks A/B/C（辯論存檔、skill更新、壓力測試）
3. Open WebUI + n8n + Supabase 儀表板管線
4. 日曆工具優化專案
5. Google Books 功能進化專案

## 教訓
1. **模型驗證**：更換模型後應立即執行 `hermes --version` 確認型號
2. **備份優先**：任何重大變更前，先備份記憶到 Supabase
3. **信任但驗證**：AI 給出的路徑和指令需先驗證存在性
