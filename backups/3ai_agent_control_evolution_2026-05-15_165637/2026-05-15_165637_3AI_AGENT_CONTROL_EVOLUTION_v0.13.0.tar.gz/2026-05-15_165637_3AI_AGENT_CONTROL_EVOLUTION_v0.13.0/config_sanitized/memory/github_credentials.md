# GitHub 認證資訊

## 帳號
- Username: `9505053-create`
- Email: `9505053@gmail.com`

## Token
- 有效 Token: [REDACTED]
- 類型: Classic PAT（scope: repo, workflow, admin:org, user, gist）
- 已過期 Token: [REDACTED]

## 認證方式
```bash
git config --global url."https://9505053-create:TOKEN@github.com/.insteadOf" "git@github.com:"
```
已設定，HTTPS + token 自動嵌入，所有 git push 自動認證。

## 建立 Repo
```bash
curl -s -H "Authorization: [REDACTED]
  -d '{"name":"repo-name","description":"描述","auto_init":false}' \
  https://api.github.com/user/repos
```

## 注意事項
- Fine-grained PAT 建立 repo 時報錯 → 改用 Classic PAT
- 這個 token 有完整權限，切勿外洩
