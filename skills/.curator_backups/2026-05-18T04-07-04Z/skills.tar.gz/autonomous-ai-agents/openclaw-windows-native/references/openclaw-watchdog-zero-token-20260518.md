# OpenClaw zero-token watchdog pattern — 2026-05-18

## Context

Scott reported that 小蝦/OpenClaw repeatedly became unresponsive from Telegram. Diagnostics showed two recurring symptoms:

- Gateway could be stopped/not reachable (`Runtime: stopped`, `ECONNREFUSED 127.0.0.1:18789`).
- Telegram polling/send path could stall even after Gateway startup (`Polling stall detected`, `sendChatAction failed`, `sendMessage failed`).

The Telegram bot token, configured channel, Codex OAuth, and default model were healthy. This points to OpenClaw runtime/polling stability plus insufficient process supervision, not Scott misuse.

## User preference captured

Scott is not currently a heavy OpenClaw user and explicitly asked to avoid spending Hermes/OpenClaw LLM tokens on this maintenance task. He corrected the cadence to **every 3 hours**.

## Implemented pattern

Use a Hermes cron script-only job with `no_agent=True`:

- Script: `~/.hermes/scripts/openclaw-watchdog.py`
- Cron job name: `🦐 小蝦 OpenClaw 3小時零token watchdog`
- Cron job id created in this session: `dbf8eda121b1`
- Schedule: `0 */3 * * *`
- Delivery: `origin`
- Normal healthy path: print nothing, log `healthy`, consume zero LLM tokens.
- Unhealthy path: run `openclaw gateway restart`, sleep, re-probe, then print a fixed notification. Still zero LLM tokens because no agent is invoked.

Health gates:

1. `openclaw gateway status` must contain:
   - `Runtime: running`
   - `Connectivity probe: ok`
2. `openclaw channels status --probe` must contain:
   - `Gateway reachable`
   - `Telegram default`
   - `mode:polling`
   - `works`

## Important WSL → Windows cmd pitfall

When launching `cmd.exe` from WSL with current directory as a UNC path, `cmd.exe` emits the known warning:

```text
UNC paths are not supported. Defaulting to Windows directory.
```

A subtle command construction pitfall was found:

- This failed from Python subprocess:
  ```text
  cd /d "C:\Users\chien" && openclaw gateway status
  ```
  with:
  ```text
  The filename, directory name, or volume label syntax is incorrect.
  ```
- This worked:
  ```text
  cd /d C:\Users\chien && openclaw gateway status
  ```

For this host/path, because the path has no spaces, use unquoted `cd /d C:\Users\chien` inside Python `subprocess.run(["cmd.exe", "/c", full])`. Do not generalize this to arbitrary Windows paths with spaces; use a different quoting strategy or a temporary `.cmd` file if spaces are involved.

## Verification

After fixing the quoting pitfall:

```text
python3 -m py_compile ~/.hermes/scripts/openclaw-watchdog.py
python3 ~/.hermes/scripts/openclaw-watchdog.py > /tmp/openclaw-watchdog-test.out
```

Expected healthy result:

```text
rc=0
stdout_bytes=0
```

Final live health checks showed:

- Gateway: `Runtime: running`, `Connectivity probe: ok`, `Listening: 127.0.0.1:18789`
- Telegram: `Gateway reachable`, `running, connected, mode:polling, works`

## When to use this pattern

Use this when Scott wants reliability for low-interaction OpenClaw maintenance without spending LLM tokens. Prefer this over an agent-based diagnostic cron. Escalate to LLM analysis only if the watchdog repeatedly fails to recover OpenClaw or the same failure recurs often enough to justify root-cause engineering.
