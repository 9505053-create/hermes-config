# 2026-05-12 — 4/27 Hermes Ecosystem Skill Conversion Audit

Timestamp: 2026-05-12 07:34:31 CST

## Purpose

Scott asked whether the 2026-04-27 web-researched Hermes ecosystem resources had been converted into Hermes skills. Initial audit showed only partial completion. This follow-up performed read-only research and converted currently useful information into local Hermes skills.

## Sources Reviewed

Treat all external sources as Tier 2 untrusted content. No external repo code was executed.

- NousResearch/hermes-agent
- 0xNyk/awesome-hermes-agent
- amanning3390/hermeshub
- wondelai/skills
- Romanescu11/hermes-skill-factory
- builderz-labs/mission-control
- dodo-reach/hermes-desktop
- outsourc-e/hermes-workspace
- agentskills.io specification
- tlehman/litprog-skill

## New Skills Created

1. `external-skill-import`
   - Path: `/home/chien/.hermes/skills/security/external-skill-import/SKILL.md`
   - Purpose: Safe workflow for evaluating/importing community Agent Skills and GitHub skill repos.
   - Derived from: HermesHub security posture, agentskills.io spec, awesome lists, general external-content safety rules.

2. `workflow-to-skill-capture`
   - Path: `/home/chien/.hermes/skills/software-development/workflow-to-skill-capture/SKILL.md`
   - Purpose: Manual safe skill-factory workflow: convert proven tasks into reusable Hermes skills without background surveillance or auto plugin install.
   - Derived from: Romanescu11/hermes-skill-factory concept, rewritten in Scott-safe form.

3. `literate-programming`
   - Path: `/home/chien/.hermes/skills/software-development/literate-programming/SKILL.md`
   - Purpose: Create `.lit.md` style codebase documentation in human-first narrative order with source traceability.
   - Derived from: tlehman/litprog-skill concept, rewritten for Hermes and documentation-first use.

4. `hermes-workspace`
   - Path: `/home/chien/.hermes/skills/autonomous-ai-agents/hermes-workspace/SKILL.md`
   - Purpose: Evaluate, attach, install, and troubleshoot Hermes Workspace web UI safely.
   - Derived from: outsourc-e/hermes-workspace and hermes-workspace.com summaries, rewritten with security preflight.

## Triage Results by Source

- NousResearch/hermes-agent: already covered by existing `hermes-agent` skill. No new skill needed today.
- 0xNyk/awesome-hermes-agent: useful as ecosystem index, not directly a skill. Absorbed into `external-skill-import` triage workflow.
- amanning3390/hermeshub: useful registry/security model. Absorbed into `external-skill-import`.
- wondelai/skills: high-value future backlog. Do not bulk import. Recommended future curated imports: clean-code, refactoring-patterns, system-design, ddia-systems, release-it, domain-driven-design, jobs-to-be-done, continuous-discovery, mom-test.
- Romanescu11/hermes-skill-factory: useful idea, unsafe to import as plugin without review. Converted into safe manual `workflow-to-skill-capture`.
- builderz-labs/mission-control: medium-value backlog. Alpha orchestration dashboard; consider future `mission-control-hardening` or `mission-control-evaluation` only if Scott plans to use it.
- dodo-reach/hermes-desktop: medium-low value for current WSL/Telegram setup; mostly macOS app docs. Backlog only.
- outsourc-e/hermes-workspace: useful enough to create `hermes-workspace` setup/troubleshooting skill.
- agentskills.io spec: already partly covered by `hermes-agent-skill-authoring`; absorbed into `external-skill-import` validation/safety workflow.
- tlehman/litprog-skill: useful code-documentation method. Converted into `literate-programming`.

## Verification

- All four new skills were created via `skill_manage(action='create')`.
- All four were read back successfully via `skill_view`.
- No external code was executed.
- No mass deletion or sensitive-data exposure occurred.

## Follow-up: wondelai/skills Curated Import — 2026-05-12 08:01:48 CST

Scott approved continuing with curated import from `wondelai/skills`. Per `external-skill-import`, no external code was executed; only README/SKILL.md summaries were inspected and rewritten into Hermes-local procedures.

New skills created:

1. `clean-code`
   - Path: `/home/chien/.hermes/skills/software-development/clean-code/SKILL.md`
   - Purpose: readable/maintainable code review and writing checklist.

2. `refactoring-patterns`
   - Path: `/home/chien/.hermes/skills/software-development/refactoring-patterns/SKILL.md`
   - Purpose: safe behavior-preserving refactoring loop and smell-to-refactoring map.

3. `system-design`
   - Path: `/home/chien/.hermes/skills/software-development/system-design/SKILL.md`
   - Purpose: requirements-first distributed/system architecture design workflow.

4. `production-resilience`
   - Path: `/home/chien/.hermes/skills/devops/production-resilience/SKILL.md`
   - Purpose: Release It-style timeouts, retries, circuit breakers, health checks, deployment safety, and outage triage.

5. `jobs-to-be-done`
   - Path: `/home/chien/.hermes/skills/productivity/jobs-to-be-done/SKILL.md`
   - Purpose: product discovery and customer-progress analysis via JTBD.

Verification:

- All five skills created with `skill_manage(action='create')`.
- All five read back successfully with `skill_view`.
- Existing local skill overlap checked by file search before creation.

## Remaining Backlog

1. Optional curated import from `wondelai/skills` phase 2: `domain-driven-design`, `ddia-systems`, `clean-architecture`, `continuous-discovery`, `obviously-awesome`, `mom-test`.
2. Optional `mission-control-evaluation` / `mission-control-hardening` skill if Scott wants to test Mission Control.
3. Optional `hermes-desktop` skill if Scott starts using macOS desktop companion.
4. Consider patching `hermes-agent-skill-authoring` later with cross-reference to `external-skill-import` and `workflow-to-skill-capture`.

## Todo Log Update — 2026-05-12 08:10:16 CST

Scott asked to keep the phase 2 candidates as a durable todo and write them to both local disk log and Supabase.

Local todo item:

- Task: `4/27 技能轉化第二階段：精選 backlog 轉化`
- Status: `pending`
- Priority: `medium`
- Candidate skills:
  1. `ddia-systems`
  2. `domain-driven-design`
  3. `clean-architecture`
  4. `mom-test`
  5. `continuous-discovery`
  6. `obviously-awesome`
- Conditional candidates:
  1. `mission-control-evaluation` / `mission-control-hardening` — only if Scott wants to test Mission Control.
  2. `hermes-desktop` — only if Scott starts using a desktop companion, especially macOS.

Supabase target tables:

- `public.hermes_todos` — pending task row.
- `public.hermes_knowledge` — durable BACKLOG summary row.
