# Agent Resilience Drill Lessons — 2026-05-14

Scott 指示：這次五項建議實作是一個很好的演練，要寫經驗教訓，並把好的構想做成記憶與技能。

## Durable Memory

當 Scott 要我「安排實做」agent 穩定性、token/context、Size Gate、Reference Block、log parser、壓力測試相關建議時，預設不要直接改 Hermes/OpenClaw core。標準模式是：

1. 建立 shared workspace 工作包。
2. 把項目分級：doc-only / standalone prototype / core patch / pressure test。
3. Core patch 前跑 3AI Council，讓 Innovator/Red Team/Pragmatist 收斂安全邊界。
4. 先落地低風險 doc/prototype，並用 py_compile + tests 驗證。
5. Size Gate 第一版應是 wrapper/interceptor，不直接改 tool execution/core loop。
6. Size Gate 不是單純截斷：必須 full output externalization + head/tail preview + structured parser summary + metadata + 不可假設 omitted content。
7. Parser 核心規則：paths alone 不代表 failure；no_signal 不代表 success。
8. Reference Block 必須有 freshness/uncertainty：stale_after、last_verified_at、source_of_truth、confidence、unknowns。
9. Boundary pressure test 必須 synthetic-only，不讀 live shared/inbox/outbox；需 Scott 明確 go/no-go。
10. 通知小蝦長規則時用 shared file + 短 CLI prompt，避免長 prompt 截斷。

## 2026-05-14 Evidence

工作包：
`C:\Users\chien\_3AI_WorkSpace\active\20260514-agent-resilience-action-items\`

Lessons file：
`C:\Users\chien\_3AI_WorkSpace\active\20260514-agent-resilience-action-items\LESSONS_LEARNED.md`

Skill：`agent-resilience-action-items`

已完成：3AI Council、parser v0.2、size_gate_wrapper standalone、Token Ledger v0.2、Reference Block v0.2、Boundary Pressure Test Plan v0.2、8 regression tests。
