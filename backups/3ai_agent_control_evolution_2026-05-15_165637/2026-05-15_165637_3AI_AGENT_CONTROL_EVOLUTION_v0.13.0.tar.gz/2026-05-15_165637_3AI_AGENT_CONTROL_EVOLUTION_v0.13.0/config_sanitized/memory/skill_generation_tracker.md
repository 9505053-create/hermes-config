# Skill 生成/修改追蹤記錄
## 用途：每週六週報素材，追蹤哪些 skill 被建立/修改/降級

---

### 2026-05-04

#### 1. `3ai-debate-workshop` — 狀態變更為 PENDING
- **動作：** 降級標記（patch SKILL.md 頂部加入降級說明）
- **原因：** 顧問團（GPT/Claude/Gemini Web）審查後發現 6 個問題
- **具體問題：**
  1. Prompt 預設結論方向
  2. 研究資料雙方不對等
  3. 未保存 raw response
  4. 自動建立 skill 過度自我擴張
  5. 觀察者角色太溫和
  6. 未回應觀察者待探索問題
- **是否涉及紅線：** 否
- **影響範圍：** 辯論工作流
- **狀態：** 正常可用（品質瑕疵不等於紅線違規，保留為可用 skill）
- **下一步：** 後續辯論優先使用 v2，v1 作為備份保留

#### 2. `3ai-debate-workshop-v2` — 新建立（Stable）
- **動作：** 全新建立
- **原因：** 修復 v1 所有缺陷，整合顧問團回饋
- **主要改動：**（見上方 v1→v2 對照表）
- **是否涉及紅線：** 否（純工作流優化，不涉及 Scott 個資/金錢/檔案刪除）
- **狀態：** Stable

#### 3. `3ai-debate-workshop-v2` — 更新為 v2.1（2026-05-04 第二輪顧問團回饋）
- **動作：** patch SKILL.md
- **原因：** 第二場辯論（資安主題）後，顧問團指出 4 個 P0 問題 + 6 個 SOP 改善
- **新增規則：**
  1. Fact Check Gate — prompt 中外部事實標註 unverified，Judge 必須 web_search 驗證
  2. Execution Health Gate — exit_code != 0 報告開頭強制品質警告
  3. Numeric Cross-check Gate — 編譯前比對所有定量數值，不一致 abort
  4. Abnormal Convergence Rule — consensus_score 跳幅 >30 強制 Verification Round
  5. Round Diff Report — 追蹤各 round 立場變化
  6. Action Item Conversion — verdict 必須輸出可執行的 Action Items
- **是否涉及紅線：** 否

#### 4. `weekly-security-audit` — 新增 Phase 1.5 Snyk Agent Scan
- **動作：** patch SKILL.md
- **原因：** 安裝 snyk-agent-scan 工具並成功掃描 6 個 skill
- **新增內容：** Phase 1.5 自動化 Skill 掃描（安裝/執行/結果解讀/Token 管理）
- **掃描結果：** 4 個 HIGH（3x W011 第三方內容暴露 + 1x W008 Secret），2 個無問題
- **SNYK_TOKEN：** 到期 2026-08-02，免費帳號，由 Scott 提供
- **是否涉及紅線：** 否（免費帳號，不涉及金錢）
