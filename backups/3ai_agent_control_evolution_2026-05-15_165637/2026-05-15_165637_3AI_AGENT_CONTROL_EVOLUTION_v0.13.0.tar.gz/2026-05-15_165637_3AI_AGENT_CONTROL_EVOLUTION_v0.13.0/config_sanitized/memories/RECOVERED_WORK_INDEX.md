# Hermes Recovered Work Index

Recovery date: 2026-05-01

## Important Recovery Note
Historical session files were restored into:

/home/chien/.hermes/sessions/

However, sessions.json may only point to the current Telegram session. If session_search returns incomplete results, directly search files under /home/chien/.hermes/sessions.

## Key Recovered Session

### session_20260429_011734_7c541d.json

Main topic:
- Hermes permission conflict
- Notion automation task continuation
- 3AI debate archive
- Notion lessons learned archive
- OpenRouter / model / config references

Important recovered Notion task:
1. Task A: Create Debate Archive structure in Notion.
2. Task B: Update 3ai-orchestrator-debate skill to include Sync to Notion as final step.
3. Record WSL / Hermes permission issue into Notion Lessons Learned / 經驗教訓館.
4. Task C: Perform Notion connection stress test.

Important technical details:
- Notion integration was previously verified.
- The intended API method was PATCH /v1/blocks/{page_id}/children.
- Use precision append strategy, not full-page rewrite.
- Avoid exposing full API keys in logs or messages.

## Memory Recovery Rule
If the user asks about Hermes / Notion / n8n / Supabase / OpenRouter work and session_search gives weak answers, do not assume no memory exists.
First directly inspect:
/home/chien/.hermes/memories/MEMORY.md
/home/chien/.hermes/memories/USER.md
/home/chien/USER_PROFILE.md
/home/chien/.hermes/sessions/

Useful command:
grep -RniE "Notion|n8n|Supabase|OpenRouter|Hermes|config.yaml|MEMORY.md|USER_PROFILE" /home/chien/.hermes/sessions | head -n 120
§
## Filesystem Context Recovery (2026-05-01) — NEW
When session_search returns incomplete results, use the `filesystem-context-recovery` skill.
This documents the full workflow for:
- Direct grep on /home/chien/.hermes/sessions/ (bypasses session_search indexing gaps)
- Reading memory files (MEMORY.md, USER_PROFILE.md, RECOVERED_WORK_INDEX.md)
- Extracting Telegram chat export PDFs via pdftotext (page ranges for 400+ page PDFs)
- Cross-referencing ALL sources to detect hallucinated data from faulty model versions
- Distinguishing V3-era hallucinations from actual Gemma 4 / V4 Pro work
Key lesson: session JSONL files contain raw conversation, but always filter out system_prompt noise.
§
## Active Projects (2026-05-01 confirmed)
1. **日曆工具優化** — Original: project_calendar_v1_9.zip (Claude-developed HTML calendar). User uploaded 4/29. Status: files missing from cache, need re-upload.
2. **Google Books 功能進化** — Claude half-finished project. User wants enhancement. Status: original source files not yet located.
Note: V3 model (4/30) hallucinated fake paths ~/projects/calendar_optimizer/ and ~/projects/google_books_crawler/ — these do NOT exist.
§
## Supabase External Brain (2026-05-01 merge)
A local Supabase snapshot from 2026-04-28 was recovered and indexed.
The database contains 69 hermes_knowledge rows (65 skills + 4 special modules), 1 debate archive, and 6 tracked tasks.
Full inventory: SUPABASE_EXTERNAL_BRAIN_INDEX.md
Staging exports: /home/chien/hermes_supabase_restore_staging_20260501-062455/
Memory backup (pre-merge): /home/chien/[REDACTED]/
§
Pending item from Supabase: hermes_todos #6 — "解決 n8n 與 Supabase 的 API 認證連接問題 (排查 401 錯誤)" — still pending as of 2026-04-28 snapshot.
§
## 3AI Work Mode (Established 2026-05-03)

### Definition
When user mentions "3AI", "3AI助手", or "3AI xxxxx", this refers to the authorized CLI tools:
- **Claude CLI** (Anthropic) — User's monthly subscription
- **CODEX CLI** (OpenAI) — User's monthly subscription
- **Gemini CLI** (Google) — User's monthly subscription

### Cost Structure
- **3AI CLIs**: Monthly subscription (fixed cost, usage limits with cooldown periods)
- **Hermes**: OpenRouter API tokens (cost money to purchase)

### Strategic Directive
Hermes is the **Commander** that strategically uses 3AI resources to save tokens (which cost money).

### Task Allocation Rules
1. **Simple tasks**: Execute directly with Hermes
2. **Complex tasks**: Delegate to 3AI first, then summarize and take final action
3. **Dynamic allocation**: No fixed assignments, can split tasks among 3AI members
4. **Cross-checking**: Can have 3AI members check each other's work

### New Skills Created
- **3ai-commander**: Strategic delegation to Claude, CODEX, and Gemini CLI
- **token-memory-manager**: [REDACTED]
- **hermes-integrations**: Complete integration guide (GitHub, Email, Google Workspace, Notion, 3AI CLIs, Supabase)

### Handoff File
For future sessions, see: `/home/chien/.hermes/handoffs/2026-05-03-3ai-work-mode-handoff.md`
