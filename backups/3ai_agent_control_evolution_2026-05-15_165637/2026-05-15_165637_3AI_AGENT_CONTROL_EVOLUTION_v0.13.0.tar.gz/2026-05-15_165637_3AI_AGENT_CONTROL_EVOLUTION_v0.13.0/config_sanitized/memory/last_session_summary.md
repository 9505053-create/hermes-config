# 會話摘要 — 2026-05-15 10:43:45 CST

## 本輪決策
- 維持 Hermes Agent `v0.13.0` 現狀，不啟用官方 Kanban，不亂升級、不改 core；優先穩定、省 token、避免 wandering。
- Hermes / 小馬定位為 MINIPC 資源指揮官：派工、限制 scope、讀回驗證、整合回報、記憶規則。
- Scott 術語定義：
  - `3AI CLI`：一般命令列諮詢 / transport，偏「看、想、說」。
  - `3AI agent`：agent runtime 進 workspace 執行，偏「讀、寫、改、驗證」。
  - `Claude CLI`：Claude 一般命令列諮詢。
  - `CLAUDE AGENT`：Claude Code agent runtime，預設 `--model opus`，目前解析為 `claude-opus-4-7`。
  - `Codex agent / cdex agent`：`codex.cmd exec` 工程 agent，預設 `--model gpt-5.5`。
  - `Gemini CLI`：Gemini 一般諮詢 / 摘要 / 第二意見。
  - `Gemini agent / GEMINI AGENT`：Gemini 在受控 workspace 進行 agentic 任務，權限較粗，需小心。
- 之後呼叫 **CLAUDE / CLAUDE AGENT** 預設指定 `--model opus` 取得最佳答覆；目前實測為 `claude-opus-4-7`。
- 之後呼叫 **CODEX AGENT** 預設指定 `--model gpt-5.5`；不使用 `gpt-5.5-pro`，因目前 ChatGPT-authenticated Codex CLI 回報不支援。
- 小蝦 / OpenClaw 使用 GPT-5.4 節省 token；小馬 / Hermes 作為指揮官享有 GPT-5.5 高階額度，但仍需穩定、省 token、該用才用。
- 複雜輸出採「Markdown-first, HTML-for-review」：Markdown 作 source of truth，HTML 作人類 review artifact。

## 完成事項
- 查證 Hermes 版本：`Hermes Agent v0.13.0 (2026.5.7)`。
- 確認 Hermes v0.13 coding workflow 功能，但 Scott 決定不啟用官方 Kanban。
- 建立 Hermes skill：`dual-md-html-output`；另行教小蝦雙輸出技能。
- 實測 Codex CLI：`C:\Users\chien\AppData\Roaming\npm\codex.cmd`，版本 `codex-cli 0.128.0`，Windows mode 寫檔成功並由 Hermes 讀回 marker：`HERMES_CODEX_SMOKE_20260515`。
- 實測 Claude Code CLI：`C:\Users\chien\AppData\Roaming\npm\claude.cmd`，版本 `2.1.126 (Claude Code)`，text-only 與寫檔皆成功；讀回 marker：`HERMES_CLAUDE_CODE_SMOKE_20260515`。
- 實測 Claude Code `--model opus`：JSON `modelUsage` 確認實際模型為 `claude-opus-4-7`，`contextWindow: 1000000`，`maxOutputTokens: 64000`。
- 實測 Codex `--model gpt-5.5-pro`：API 回錯 `The 'gpt-5.5-pro' model is not supported when using Codex with a ChatGPT account.`；exit code 1，未建立測試輸出檔。
- 建立 Hermes-only skill：`minipc-3ai-review-orchestrator`，用於小馬獨享的 MINIPC 3AI agent orchestration，不同步給小蝦。
- 確認 Scott 建立的 agent 專屬工作區存在：
  - `C:\Users\chien\_3AI_WorkSpace\_agent\Claude Codex\`
  - `C:\Users\chien\_3AI_WorkSpace\_agent\Codex\`
  - `C:\Users\chien\_3AI_WorkSpace\_agent\Gemini Workspace\`
- 建立 routing 說明檔：`C:\Users\chien\_3AI_WorkSpace\_agent\AGENT_WORKSPACE_ROUTING.md`。

## 待辦/未完成
- 未實測 Gemini agent 最新狀態與高階模型；目前保留既有 Windows mode 規則與受控使用原則。
- 未在新 agent workspace 中跑完整 3AI review pipeline；目前只完成 smoke/probe 測試。

## 重要上下文
- 主要語言：繁體中文。
- Hermes 在 WSL；Windows host 路徑透過 `/mnt/c/...` 存取。
- Windows workspace：`C:\Users\chien\_3AI_WorkSpace\`。
- Agent 專屬 workspace routing：
  - Claude agent / Claude Code：`C:\Users\chien\_3AI_WorkSpace\_agent\Claude Codex\`
  - Codex agent：`C:\Users\chien\_3AI_WorkSpace\_agent\Codex\`
  - Gemini agent：`C:\Users\chien\_3AI_WorkSpace\_agent\Gemini Workspace\`
- 常用命令模板：
  - Claude agent / Opus 4.7：`cmd.exe /c "cd /d C:\Users\chien\_3AI_WorkSpace\_agent\Claude Codex && type prompt.txt | claude.cmd --print --model opus --allowedTools Bash Write Edit"`
  - Claude CLI / Opus 4.7 純諮詢：`cmd.exe /c "cd /d C:\Users\chien\_3AI_WorkSpace\_agent\Claude Codex && type prompt.txt | claude.cmd --print --model opus"`
  - Codex agent / GPT-5.5：`cmd.exe /c "cd /d C:\Users\chien\_3AI_WorkSpace\_agent\Codex && type prompt.txt | codex.cmd exec --skip-git-repo-check --sandbox workspace-write --model gpt-5.5"`
  - Gemini agent：`cmd.exe /c "cd /d C:\Users\chien\_3AI_WorkSpace\_agent\Gemini Workspace && type prompt.txt | gemini.cmd --skip-trust --approval-mode yolo"`
- CLI agent 磁碟 I/O 原則：Windows Native / WINDOWS MODE；長 prompt 寫檔後 pipe；不信自稱完成，必須讀回檔案 / 查 diff / 跑測試。
- 安全邊界：不把 secrets / credentials / API keys / token / 信用卡 / 私密個資丟給外部 CLI agent；大量刪除 5+ 檔案或遞迴刪除資料夾前問 Scott。

## 技能異動
- 新增：`dual-md-html-output`。
- 新增：`minipc-3ai-review-orchestrator` — Hermes-only，不同步小蝦。
- 更新：`3ai-windows-mode-disk-io`、`3ai-commander`、`claude-code`、`codex`。
