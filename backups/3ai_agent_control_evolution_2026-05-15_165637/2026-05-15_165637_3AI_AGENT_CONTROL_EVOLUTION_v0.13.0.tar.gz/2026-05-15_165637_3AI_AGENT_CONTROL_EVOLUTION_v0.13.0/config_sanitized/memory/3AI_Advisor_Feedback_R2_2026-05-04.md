# 3AI Web 顧問團第二輪回饋 — 資安辯論審查
日期：2026-05-04
來源：GPT Web / Claude Web / Gemini Web

## 三方共同指出的關鍵問題

### 🔴 P0：必須立即修

#### 1. Consensus Score 不一致（三方都提到）
- Debate_Record.md = 75
- verdict.md / debate_summary.md = 85
- raw Gemini = 68→85
- 原因：Hermes 編譯時沒做數字 cross-check

#### 2. Gemini 兩輪 timeout（exit_code 124）沒在報告顯眼處標示
- manifest 有註記但 Debate_Record 開頭沒品質警告
- timeout 可能影響裁決可信度

#### 3. 所有研究資料未經獨立 fact check
- manifest 全部 web_search_used: false
- 辯論建在 Hermes 一個來源上，可信度要降一級

#### 4. Builder Round 2 太弱，收斂可能太快
- Red Team 29 行 vs Builder 13 行
- 35→75 跳幅 >30，應視為異常收斂
- Builder 幾乎是接受而不是被說服

### 🟡 P1：納入辯論 SOP v2

#### 5. Fact Check Gate
- prompt 中所有引用事件加 [source: xxx, unverified]
- Judge 至少驗證 2 個關鍵數據
- manifest 紀錄 web_search 使用情況

#### 6. Execution Health Gate
- exit_code != 0 → 報告開頭強制品質警告

#### 7. Numeric Cross-check Gate
- 編譯前比對 raw vs summary vs verdict 的定量數值
- 不一致就 abort

#### 8. Abnormal Convergence Rule
- consensus_score 單輪跳幅 >30 → 強制 Verification Round

#### 9. Round Diff Report
- 追蹤每方在各 round 的立場變化（堅持/軟化/撤回/新增）

#### 10. Action Item Conversion
- verdict 必須輸出 Strategic Insights + Action Items + Owner + Risk Level

### 🟢 P2：Scott 工作流改善

#### 11. Behavioral Manifest（GPT + Gemini）
- 新工具/Skill 附上行為清單（允許做什麼 / 禁止做什麼）

#### 12. 危險操作人工確認 Gate（GPT + Claude）
- 刪除大量檔案、修改 .env/API key、對外寄信/上傳、改防火牆/systemd
- 設成硬規則，不交給模型判斷

#### 13. 網路出口 allowlist（GPT + Red Team 底線）
- 預設禁止未知網域
- 只允許必要服務

#### 14. 記憶分級（GPT + Gemini）
- 高：Scott 確認過的 SOP
- 中：AI 產出的技術建議
- 低：網頁/論壇/外部文章

#### 15. Shadow Run Report（GPT + Gemini）
- 新工具前 N 次輸出實際會讀/寫/連的東西

---

## GPT 最終建議（優先順序）
1. Hermes cross-check 驗證
2. Judge fact check
3. timeout 升級為報告警告
4. Behavioral Manifest + Shadow Run
5. 危險操作 Scott 人工確認

## Claude 一句話
辯論論點品質高，但彙整/驗證/落地三段都有缺口。

## Gemini 一句話
多模型互審是語意完整性校驗最有效且低成本的手段。
