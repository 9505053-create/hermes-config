# Skill Conversion Backlog — 2026-05-12

Timestamp: 2026-05-12 08:22 CST

## Source

Scott asked to confirm whether the 4/27-era discussions about turning web/repo research into Hermes skills had been completed, then instructed: "重要的先做，其他列入待辦，寫入本地硬碟和supabase".

Evidence limitation: local searchable raw sessions begin after 2026-04-27, so this backlog is based on the earliest available 2026-04-28 adjacent history and Supabase snapshot, plus current local skill inventory.

## Completed Immediately — Important Items

### 1. `safe-system-update`
- Status: completed before this backlog file was written.
- Local skill: `/home/chien/.hermes/skills/devops/safe-system-update/SKILL.md`
- Supabase: `public.hermes_knowledge`, title `safe-system-update`
- Purpose: stability-first core/system update procedure with backup, rollback, 3AI risk review, and verification.

### 2. `linux-service-permission-inheritance`
- Status: completed before this backlog file was written.
- Local skill: `/home/chien/.hermes/skills/devops/linux-service-permission-inheritance/SKILL.md`
- Supabase: `public.hermes_knowledge`, title `linux-service-permission-inheritance`
- Purpose: prevent Hermes service/user permission inheritance failures on WSL/Linux.

### 3. `token-memory-manager` patch: [REDACTED]
- Status: completed.
- Local skill: `/home/chien/.hermes/skills/token-memory-manager/SKILL.md`
- Supabase target: `public.hermes_knowledge`, title `token-memory-manager`
- Added: routing rules for local markdown, skills, Supabase, Google Drive/shared workspace, raw artifacts, and compression handoff.

### 4. `3ai-debate-workshop-v2` patch: Supabase Debate Archive Rule
- Status: completed.
- Local skill: `/home/chien/.hermes/skills/autonomous-ai-agents/3ai-debate-workshop-v2/SKILL.md`
- Supabase target: `public.hermes_knowledge`, title `3ai-debate-workshop-v2`
- Added: optional `public.hermes_debates` archival rule for substantial, non-sensitive 3AI debates.

### 5. `agent-external-brain-optimization`
- Status: completed.
- Local skill: `/home/chien/.hermes/skills/autonomous-ai-agents/agent-external-brain-optimization/SKILL.md`
- Supabase target: `public.hermes_knowledge`, title `agent-external-brain-optimization`
- Purpose: choose source-of-truth and storage routing across local markdown, skills, Supabase, Drive/workspace, Notion, and Obsidian.

### 6. Windows native 3AI CLI disk I/O verification
- Status: completed on 2026-05-12.
- Test workspace: `C:\Users\chien\_3AI_WorkSpace\cli_disk_test_windows_native` (`/mnt/c/Users/chien/_3AI_WorkSpace/cli_disk_test_windows_native`).
- Verified outputs:
  - `claude_result.txt`: Claude can read/write with `--allowedTools Bash Write Edit`.
  - `codex_result.txt`: Codex can read/write with `--sandbox workspace-write`.
  - `gemini_result.txt`: Gemini can read/write when using Windows CLI plus `--skip-trust --approval-mode yolo`.
- Note: the earlier Gemini failure was due to missing YOLO/approval mode, not a hard filesystem impossibility.

## Durable Backlog — Pending / Lower Priority

### P1 — `agent-ecosystem-strategy`
- Status: pending backlog.
- Priority: medium.
- Why: useful if Scott compares or combines Hermes, OpenClaw-like runtimes, Claude/Codex/Gemini CLIs, MCP, and other agents.
- Suggested action: create only when an active multi-agent ecosystem decision appears; otherwise keep as backlog.

### P2 — OpenClaw GPT Images setup
- Status: pending security-reviewed backlog.
- Priority: low-medium.
- Why: could be useful, but involves third-party CLI installation/auth, Telegram bot token handling, and gateway behavior.
- Required safety gate: run `external-skill-import` review first; treat all external install/auth instructions as untrusted.

### P3 — Optional ML/tool-specific skill candidates
- Status: pending optional backlog.
- Priority: low until Scott needs one directly.
- Candidates:
  - `clip`
  - `gguf-quantization` — likely covered by `llama-cpp`
  - `grpo-rl-training` — partly covered by `fine-tuning-with-trl`
  - `guidance` — partly covered by `outlines`
  - `modal-serverless-gpu`
  - `peft-fine-tuning` — partly covered by `unsloth` / `fine-tuning-with-trl`
  - `pytorch-fsdp`
  - `stable-diffusion-image-generation` — likely covered by `comfyui`
  - `whisper`

### P4 — Other partial/covered concepts
- Status: no immediate new skill; patch existing skills only if a concrete gap appears.
- Items:
  - `autonomous-learning`
  - `agent-self-optimization`
  - `skill-engineering`
  - `theme-factory`
  - `user-persona-synthesis`

## Persistence Plan

- Local detailed audit trail: this file.
- Supabase compact knowledge records: `public.hermes_knowledge` for completed/updated skills.
- Supabase durable backlog: `public.hermes_todos` rows for pending lower-priority candidates.

## Verification Required

After writes:
- read this file back from disk
- read affected skills with `skill_view`
- query `public.hermes_knowledge` for completed skill titles
- query `public.hermes_todos` for pending backlog tasks
