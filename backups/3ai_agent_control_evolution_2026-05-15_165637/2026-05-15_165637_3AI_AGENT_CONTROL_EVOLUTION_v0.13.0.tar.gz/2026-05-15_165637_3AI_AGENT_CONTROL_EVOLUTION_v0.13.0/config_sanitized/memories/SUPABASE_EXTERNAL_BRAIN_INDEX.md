# Supabase External Brain Index (Updated 2026-05-03)

**Last Updated**: 2026-05-03 00:35 UTC
**Source**: Local Supabase (Docker, /mnt/c/docker/supabase/, supabase-db container)
**Database**: postgres
**Backup snapshot date**: 2026-04-28 (original) + 2026-05-01 (recovery data)

This file documents the existence, structure, and contents of the Hermes external brain stored in the local Supabase PostgreSQL instance. It serves as a recovery index — if the agent loses context, read this file to know what exists in Supabase and how to reconnect.

---

## Quick Connection

```bash
# Direct psql (no password needed inside container)
docker exec -u postgres supabase-db psql -d postgres

# Or via pooler on port 15432
PGPASSWORD=[REDACTED]
  psql -h localhost -p 15432 -U supabase_admin -d postgres
```

---

## Table Inventory (Updated)

### 1. public.hermes_knowledge — 71 rows (Main Knowledge Base)

| Module | Rows | Description |
|--------|------|-------------|
| mlops | 22 | MLOps skill definitions |
| creative | 14 | Creative tool skill definitions |
| autonomous-ai-agents | 11 | Agent orchestration skill definitions |
| productivity | 8 | Productivity tool skill definitions |
| github | 6 | GitHub workflow skill definitions |
| devops | 4 | DevOps skill definitions |
| RECOVERY | 2 | Recovery logs from 2026-05-01 session |
| LESSONS | 1 | Case 01: WSL permission conflict |
| DEBATE | 1 | Debate archive structure template |
| COGNITION | 1 | User profile framework (template only, empty) |
| TODO | 1 | Task tracking system description (template only) |

**Structure**: (id SERIAL PK, module TEXT, title TEXT UNIQUE, content TEXT, tags TEXT[], updated_at TIMESTAMPTZ)
**Indexes**: PK on id, btree on module, unique on title
**Date range**: 2026-04-28 ~ 2026-05-01 (recovery data added)

### 2. public.hermes_debates — 1 row (3AI Debate Archive)

| ID | Title | Created |
|----|-------|---------|
| 1 | 範例：第二大腦遷移方案辯論 | 2026-04-28 |

Contains a real 3-round debate (Innovator / Skeptic / Pragmatist) about migrating from Notion to Supabase. See standalone reference file for full content.

### 3. public.hermes_todos — 6 rows (Task Tracking)

| ID | Task | Status | Priority |
|----|------|--------|----------|
| 1 | 建立 Supabase 第二大腦基礎結構 | completed | high |
| 2 | 同步所有 Agent 技能至技能館 | completed | medium |
| 3 | 遷移 WSL 權限衝突經驗教訓 | completed | high |
| 4 | 遷移認知館基礎框架 | completed | medium |
| 5 | 清理 Notion 冗餘項目並遷移精華 | completed | medium |
| 6 | 解決 n8n 與 Supabase 的 API 認證連接問題 (排查 401 錯誤) | **pending** | medium |

---

## 3AI Work Mode (NEW - 2026-05-03)

### Definition
When user mentions "3AI", "3AI助手", or "3AI xxxxx", this refers to the authorized CLI tools:
- **Claude CLI** (Anthropic) — User's monthly subscription
- **CODEX CLI** (OpenAI) — User's monthly subscription
- **Gemini CLI** (Google) — User's monthly subscription

### Cost Structure
- **3AI CLIs**: Monthly subscription (fixed cost, usage limits with cooldown periods)
- **Hermes**: OpenRouter API tokens (cost money to purchase)

### Strategic Directive
Hermes is the **Commander** that strategically uses 3AI resources to save tokens (which cost money).

### Task Allocation Rules
1. **Simple tasks**: Execute directly with Hermes
2. **Complex tasks**: Delegate to 3AI first, then summarize and take final action
3. **Dynamic allocation**: No fixed assignments, can split tasks among 3AI members
4. **Cross-checking**: Can have 3AI members check each other's work

---

## New Skills Created (2026-05-03)

### 1. 3ai-commander
- **Purpose**: Strategic delegation to Claude, CODEX, and Gemini CLI
- **Location**: `/home/chien/.hermes/skills/3ai-commander/SKILL.md`
- **Key Features**: Dynamic task allocation, token saving, 3AI coordination

### 2. token-memory-manager
- **Purpose**: Dynamic token management and memory continuity across sessions
- **Location**: `/home/chien/.hermes/skills/token-memory-manager/SKILL.md`
- **Key Features**: Conversation consolidation, memory preservation, Supabase integration

---

## What Is NOT in Supabase

These items exist in local memory files but were never synced to Supabase:

- User profile data (Scott's identity, preferences, infrastructure) → see USER_PROFILE.md
- Notion Task A (Debate Archive structure in Notion)
- Notion Task B (Update 3ai-orchestrator-debate skill with Sync to Notion)
- Notion Task C (Notion connection stress test)
- 3AI Work Mode definition (2026-05-03)
- New skills: 3ai-commander, token-memory-manager
- Any work after 2026-05-01

---

## Key Known Issue: Tags Column

The `tags TEXT[]` column exists in hermes_knowledge but is **completely empty for all 71 rows**. The classification system was designed but never populated. This should be fixed when rebuilding the external brain.

---

## Recovery Procedure

If the agent needs to recover long-term memory from Supabase:

1. Read this file first
2. Check the staging export at /home/chien/hermes_supabase_restore_staging_20260501-062455/ for full JSON exports
3. Connect to Supabase via docker exec (see Quick Connection above)
4. Cross-reference with local memory files (MEMORY.md, USER.md, USER_PROFILE.md, RECOVERED_WORK_INDEX.md)
5. Local memory files are more current; Supabase provides historical snapshot and skill inventory

---

## Related Files

- Staging exports: /home/chien/hermes_supabase_restore_staging_20260501-062455/
- Merge plan: /home/chien/hermes_supabase_restore_staging_20260501-062455/MERGE_PLAN.md
- Debate standalone: /home/chien/.hermes/reference/debate_notion_to_supabase_20260428.md
- Memory backup: /home/chien/[REDACTED]/
- RECOVERED_WORK_INDEX.md (cross-reference at bottom)
- MEMORY.md (contains Core Stability Lesson covering the same WSL event)
- New skills: /home/chien/.hermes/skills/3ai-commander/SKILL.md
- New skills: /home/chien/.hermes/skills/token-memory-manager/SKILL.md
