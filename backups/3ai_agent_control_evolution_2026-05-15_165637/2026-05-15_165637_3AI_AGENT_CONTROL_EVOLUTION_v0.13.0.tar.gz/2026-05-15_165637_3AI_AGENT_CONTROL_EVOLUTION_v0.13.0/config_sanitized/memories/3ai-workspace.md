# 3AI 共享空間工作流程 (利器技能)
Updated: 2026-05-03 22:40

## 共享空間路徑
- **Windows**: `C:\Users\chien\_3AI_WorkSpace`
- **WSL**: `/mnt/c/Users/chien/_3AI_WorkSpace`

## 目錄結構
```
_3AI_WorkSpace/
├── INDEX.md           # 索引 (必讀)
├── active/            # 工作進行區 (Hermes + 3AI)
├── completed/         # 工作完成區 (Scott 查閱)
│   └── YYYY-MM-DD_專案名_v版/
│       ├── README.md      # 摘要 + 3AI 評分
│       ├── *_code/        # 原始碼
│       ├── *_review.md    # 審核請求
│       └── *_result.md    # 3AI 審核結果
├── logs/              # 系統日誌 (Hermes 自救)
│   ├── memory/        # 重要記憶備份
│   └── recovery/      # 崩潰復原 SOP
├── intel/             # 網路情報 (技術/新聞/研究)
├── debates/           # 辯論區 (3AI 辯論 + Hermes 點評)
└── temp/              # 暫存 (7天自動清理)
```

## 核心工作流程
```
1. 任務開始 → active/ 建立 MD
2. 調度 3AI → 管道 stdin 呼叫
3. 收集結果 → active/ 存結果
4. 完成 → 整包移到 completed/
```

## 已驗證呼叫命令
```bash
# Claude
cmd.exe /c "cd /d C:\Users\chien\_3AI_WorkSpace && type prompt.txt | claude.cmd --print"

# CODEX
cmd.exe /c "cd /d C:\Users\chien\_3AI_WorkSpace && type prompt.txt | codex.cmd exec --skip-git-repo-check"

# Gemini
cmd.exe /c "cd /d C:\Users\chien\_3AI_WorkSpace && type prompt.txt | gemini.cmd --skip-trust"
```

## 關鍵注意
- `-p` 參數會截斷 → 用 stdin 管道
- CODEX 只讀沙箱 → Hermes 寫結果
- Gemini 寫入可能 500 → 從 stdout 收集
- Claude 寫入需 Scott 授權

---

## Notion 讀寫能力 ✅
- API Key 已設定 (`NOTION_API_KEY`)
- 可建立/搜尋/刪除頁面
- 建立頁面後記錄回傳 `id`（不要從 URL 解析 UUID）
- 詳見教訓: `lessons/system/2026-05-04_Notion_UUID解析錯誤.md`

## Google Drive 完整 CRUD ✅
- OAuth Token 已更新（含 `drive` + `documents` + `spreadsheets` + `gmail` + `calendar` + `contacts` 權限）
- 工作資料夾 ID: `1F6ZL7mX_gyxj9V4ylHVpyoZAK6b7gztd`
- 可建立/讀取/更新/刪除檔案與資料夾
- Token 過期時用 refresh_token 自動刷新
- 詳見技能: `skills/google-drive-crud`

---

## 本地 Supabase ✅
- Docker 環境：`/mnt/c/docker/supabase/`（13 個容器，全部 healthy）
- 連線方式：`docker exec -u postgres supabase-db psql -d postgres`
- 讀寫刪除：全部正常
- 6 張表：`hermes_knowledge` (71), `hermes_debates` (1), `hermes_todos` (6), `hermes_skill_log` (14), `hermes_weekly_reports` (5), `hermes_system_secrets` (16)
- 待解決：todo #6 — n8n 與 Supabase API 認證連接 401 錯誤

## 開發原則

### 先找開源，不重新造輪子
- 開發任何新功能前，先搜 GitHub / PyPI
- 通用功能（PDF、OCR、CLI框架等）幾乎一定有現成方案
- 評估標準：Stars > 100、6個月內更新、License 友善
- 找到 → 套用；部分匹配 → 參考改寫；找不到 → 自己開發
- 記錄技術選型理由到專案 README
