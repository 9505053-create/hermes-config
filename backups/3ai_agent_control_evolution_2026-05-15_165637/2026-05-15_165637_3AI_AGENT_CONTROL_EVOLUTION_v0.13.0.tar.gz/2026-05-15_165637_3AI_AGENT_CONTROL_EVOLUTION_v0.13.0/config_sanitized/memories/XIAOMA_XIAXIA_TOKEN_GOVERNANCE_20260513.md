# 小馬 / 小蝦 / 3AI Token Governance — 2026-05-13 19: [REDACTED]

## Source / evidence scope
- Current Telegram discussion with Scott on 2026-05-13.
- 小馬 ↔ 小蝦 two-round token-saving consultation: [REDACTED]
  - `/mnt/c/Users/chien/_3AI_WorkSpace/_OpenClaw/reports/20260513_175958_token_saving_final_summary.md`
- 3AI CLI debate final summary:
  - `/mnt/c/Users/chien/_3AI_WorkSpace/debates/2026-05-13_1852_token_saving_3ai/final/final_summary.md`
- Relevant skills inspected/updated: `token-memory-manager`, `3ai-commander`, `openclaw-windows-native`.

## Durable decision
Scott explicitly said this discussion is valuable and must not be treated as ordinary chat. Preserve it as long-term operating doctrine.

Core principle:
> Token saving is not just shorter answers. It is reducing re-thinking, re-reading, wandering, unnecessary multi-agent calls, and unnecessary heavyweight agent runtime startup.

## 小馬 / 小蝦 consensus
1. Every task is first classified: short answer / deterministic execution / research / multi-step project.
2. Short answers should not launch 小蝦 or other heavyweight agents.
3. Deterministic tools come first for file reads, searches, shell/API checks, logs, arithmetic, and system state.
4. Context passed to agents should be excerpts, summaries, indexes, or file paths — not full transcripts or raw logs.
5. Consultation is capped: simple topics 1 round, standard discussion 2 rounds, complex topics at most 4 rounds unless Scott explicitly approves more.
6. Reusable conclusions must be externalized to SOP / memory / skill.

## Critical empirical observation
OpenClaw / 小蝦 can carry a high fixed runtime cost even when the answer is short:
- Round 1 observed usage: total about 98,842 tokens, cacheRead about 97,280.
- Round 2 observed usage: total about 99,642 tokens, input about 95,612.

Therefore, using 小蝦 is not automatically token-cheaper and meaningless waste/repeated retries should still be avoided. Scott later clarified the practical policy: [REDACTED]

## 3AI debate final governance model
Hybrid Token Governance: [REDACTED]
1. Deterministic Gate — cap and filter tool outputs; large outputs become artifacts first.
2. Anchor Layering — preserve stable anchors (decisions, contracts, file paths, invariants); compress only process reasoning.
3. Event-driven Compression — compress at task boundaries, artifact stabilization, context threshold, or decision completion, not blindly by timer.
4. Token Ledger mindset — compare cost of reading context vs. writing a small script/query/filter.

## Routing ladder
1. 小馬 direct answer.
2. 小馬 deterministic tools.
3. Single CLI consultation: 小蝦 / Claude / CODEX / Gemini based on fit.
4. Multiple CLI consultation when reliability or viewpoint diversity matters.
5. Formal 3AI debate only for explicit requests, architectural/strategic/safety-sensitive/high-impact decisions.

## Current persistence status
- `token-memory-manager` includes Agent Invocation Cost Gate and Hybrid Token Governance.
- `3ai-commander` includes Flexible CLI Consultation Routing.
- `openclaw-windows-native` should remember that 小蝦/OpenClaw has high fixed context/runtime cost and should not be launched casually.

## Pending improvements
- Define concrete Token Ledger warning levels.
- Design a reusable Reference Block template for stable anchors.
- Consider Size Gate implementation for large shell/read_file/log outputs.
- Let 小蝦 perform bounded stress tests only if Scott asks or if a high-impact filtering policy needs verification.

## Secrets policy
No API keys, tokens, passwords, or credit-card data are stored in this note.
