# Token Governance Mind Map v3 Implementation Record — 2026-05-16

This reference captures the concrete implementation pattern that passed review after Scott's 3AI critique loop. It is not a one-off story; use it as a model for future governance/operational mind maps.

## Trigger

Use this pattern when a mind map is really an operational governance diagram: a central principle, 5–6 decision modules, and a need for readers to know what to do next rather than merely understand a taxonomy.

## Final Layout Pattern

- Canvas: desktop overview 1600×900.
- Left lane: `STEP 1` / execution or task-flow governance, numbered ①–③.
- Center: large principle node, visually dominant.
- Right lane: `STEP 2` / context, memory, cost, safety, or control governance, numbered ④–⑥.
- Top-right TL;DR: action trigger, not a paraphrase of the center.
- Bottom: light pill slogan, not a heavy dark banner.
- Final outputs must be copied to Windows-visible paths before reporting to Scott.

## Final Copy Pattern

Center:

```text
Token 不是省出來的
是設計出來的
```

Center subtitle should be the stable principle:

```text
原則：Hermes 管決策，3AI 做重活，工具先處理資料。
```

TL;DR should be an action instruction:

```text
先路由，再執行；先工具，再上下文
遇到任務先問：Hermes 直接做，還是交給 3AI / 工具？
```

Example six-card copy:

1. 控場 — 誰總控？
   - 觸發：多步驟 / 多工具 / 需驗收
   - Hermes：拆任務、派工、收斂
   - 不做：搬資料、全掃描、重實作

2. 路由 — 交給誰？
   - 短答：Hermes 直接處理
   - 標準：3AI 單一夥伴 1–2 輪
   - 高風險：三方審核，Hermes 裁決

3. 工具先行 — 資料先去哪？
   - 觸發：多檔 / 長 log / 大資料
   - 工具：腳本、API、搜尋先抽樣
   - 只給：錯誤、路徑、首例、計數

4. 上下文壓縮 — 何時壓？
   - 觸發：40 輪 / 70% context
   - 產出：決策、anchors、待辦
   - 指令：`~~ 換窗摘要`

5. 記憶外部化 — 怎麼不重來？
   - Skill：可重複方法
   - Memory：偏好 / 長期設定
   - Handoff：本任務狀態

6. 成本 / 安全閘門 — 怎麼防失控？
   - 成本：訂閱優先，`OpenRouter` 備援
   - 迴圈：派工前先設輪次上限
   - 停止：`hard stop` 防 wandering

Bottom slogan:

```text
操作口訣：短任務直接做｜長任務先路由｜重資料先抽樣｜到邊界就交接
```

## Concrete Pitfalls Found and Fixed

1. **Card height too small**
   - Problem: 138px high cards clipped bottom rows.
   - Fix: increase card height to about 156px or reduce row text.
   - Verification: browser vision must explicitly confirm bottom rows are complete.

2. **CJK orphan break in subtitle**
   - Problem: `資料` split as `資 / 料`.
   - Fix: shorten the subtitle before tuning pixel layout.
   - Good example: `token 花在決策，不搬資料。`

3. **Lane labels too close to first card**
   - Problem: zone labels visually squeezed by first card.
   - Fix: move first cards down or increase lane header space; keep labels independent.

4. **User-facing final paths**
   - Problem: reporting WSL `/tmp` paths forced Scott to ask for Windows paths.
   - Fix: write/copy artifacts directly under `C:\Users\chien\_3AI_WorkSpace\artifacts\...` or `temp_for-Scott\...` and report Windows paths first.

5. **Final image media path vs report path**
   - Telegram media attachment may use a Linux absolute path, but the human-facing file location in prose must be Windows format.

## Verification Prompt That Worked

Use a targeted browser-vision prompt after rendering:

```text
重新檢查修正後 Token Governance v3 是否可交付。重點：卡片底部文字是否完整、主標副標是否無 CJK 孤字斷行、zone label 是否不被卡片擠壓；同時檢查閱讀動線、icon 一致性、TL;DR 正交、連線、底部口訣。若可交付請明確說可交付並產生最終截圖。
```

A good vision pass should explicitly mention:

- card bottom rows complete
- no CJK orphan break
- lane labels not squeezed
- sequence order clear
- icon style consistent
- TL;DR not a seventh branch
- lines do not cross text
- bottom slogan readable but not dominant

## Artifact Convention

For this class of deliverable, use a stable Windows-visible artifact directory such as:

```text
C:\Users\chien\_3AI_WorkSpace\artifacts\token-governance-mindmap\
```

Expected files:

```text
hermes_token_governance_mindmap_v3.html
hermes_token_governance_mindmap_v3.png
```
