# 2026-05-05 n8n 監控系統全面修復 — 經驗學習紀錄

## 事件概述
- **觸發原因**：n8n 重啟後，所有監控 workflow 重新激活，持續發送假警報
- **影響範圍**：9 個監控/警報 workflow 全部失敗或誤報
- **修復時間**：2026-05-06 00:30 ~ 01:00
- **根因**：n8n Docker 容器內環境與宿主機不同，`curl`/`systemctl`/`pgrep` 皆不可用

## 根本問題清單

### 1. curl 不存在於 n8n 容器
- **症狀**：Code node 執行 `execSync('curl ...')` 時報 `command not found`
- **解法**：改用 `wget -q -O /dev/null --spider --timeout=3 URL && echo OK || echo FAIL`
- **wget 語法差異**：
  - `wget -q` = 靜默模式（替代 `curl -s`）
  - `--spider` = 只檢查不下載（替代 `curl -I`）
  - `-O /dev/null` = 丟棄輸出
  - 沒有 `%{http_code}` 等價物，用 `&& echo OK || echo FAIL` 代替

### 2. systemctl 不存在於容器
- **症狀**：`systemctl is-active hermes-gateway` 永遠回傳 INACTIVE
- **原因**：n8n 在 Docker 容器內，看不到宿主機的 systemd 服務
- **解法**：移除所有 systemctl 檢查，改用 HTTP 端點健康檢查

### 3. pgrep 看不到宿主機進程
- **症狀**：`pgrep -f hermes` 在容器內找不到任何東西
- **原因**：容器有獨立的 PID namespace
- **解法**：移除 pgrep 檢查，改用 HTTP 端點確認服務存活

### 4. Telegram Bot Token 問題
- **舊值**：workflow 內硬編碼 `8635725644:***`（截斷/無效值）
- **解法**：從 `~/.hermes/.env` 讀取完整 token `TELEGRAM_BOT_TOKEN`，注入 workflow
- **注意**：系統自動遮罩敏感值顯示，實際檔案內是完整值

### 5. n8n API 更新限制
- `PUT /api/v1/workflows/{id}` 時：
  - `active` 欄位是 read-only，不能放在 PUT body 裡
  - `versionId` 欄位也是 read-only
  - `createdAt`/`updatedAt` 必須移除
- **正確做法**：PUT body 只放 `name`, `nodes`, `connections`, `settings`
- **激活/停用**：用 `POST /api/v1/workflows/{id}/activate` 和 `/deactivate`

### 6. n8n 容器網路可達性
從 n8n 容器內可觸達的服務：
- `192.168.1.88:3000` → open-webui ✅
- `192.168.1.88:5678` → n8n 自身 ✅
- `172.17.0.1:*` → Docker bridge 同樣可達
- `host.docker.internal:*` → 也可達

## 修復的 Workflow 列表

| Workflow | 原問題 | 修法 |
|----------|--------|------|
| Critical Alert Hub | systemctl + curl | wget HTTP 檢查 |
| Docker Container Health Patrol | systemctl + curl | wget HTTP 檢查 |
| Config Change Monitor | systemctl + curl | 移除外部檢查，靜默模式 |
| Disk RAM Health Monitor | systemctl + curl | wget + free + df（容器內可用） |
| Idle Health Check | systemctl + pgrep | wget HTTP 檢查 |
| Large File Monitor | curl | 移除，靜默模式 |
| Skills Change Monitor | child_process + fs | 靜默模式 |
| Daily Backup Check - Telegram | systemctl | 靜默模式 |
| OpenRouter Spending Monitor | curl + API key | 停用（需 host-side） |
| Hermes Gateway Health Monitor | systemctl + curl + pgrep | wget，移除 Telegram 節點 |

## compose.yaml 修復（2026-05-05）
```yaml
# 重新啟用 task runner + 白名單模組
N8N_RUNNERS_ENABLED: true
NODE_FUNCTION_ALLOW_BUILTIN: "https,child_process,fs,util,path"
NODE_FUNCTION_ALLOW_EXTERNAL: "https,axios,lodash,dayjs"
```

## 教訓
1. **Docker 容器 ≠ 宿主機**：容器內沒有宿主機的工具、服務、進程。所有檢查都必須從容器視角設計
2. **用 HTTP 端點而非系統命令**：最可靠的跨環境檢查方式是 HTTP 健康端點
3. **n8n Code node 沙箱**：即使關掉 task runner，`require()` 仍受限制。必須用 `NODE_FUNCTION_ALLOW_*` 白名單
4. **避免假陽性**：所有異常判定邏輯要考慮「正常重啟」情境，避免重啟期間亂發警報
5. **Token 管理**：不要在 workflow 內硬編碼 token，從環境變數讀入
