# Handoff before Telegram `/restart` — 2026-05-13 19:32 CST +0800

## User / conversation
- User: Scott
- Assistant nickname: 小馬
- Platform: Telegram DM
- User is considering running `/restart` so gateway reloads config changes, but wants continuity for follow-up discussion.

## Immediate context
Scott asked why Telegram showed a warning screenshot:

```text
Compression summary failed:
Error code: 400 - The 'google/gemini-3-flash-preview' model is not supported when using Codex with a ChatGPT account.
Inserted a fallback context marker.
```

Diagnosis:
- Main model/provider: `openai-codex` / `gpt-5.5`.
- Auxiliary compression was mismatched: `provider: auto`, `model: google/gemini-3-flash-preview`.
- Hermes routed the OpenRouter/Gemini slug to the Codex/ChatGPT endpoint, causing HTTP 400.
- This affects compression summary quality, not normal chat execution.

## Changes already made
Config file changed:
- Path: `/home/chien/.hermes/config.yaml`
- Backup: `/home/chien/.hermes/config.yaml.bak_aux_compression_20260513_192915`

New config:
```yaml
auxiliary:
  compression:
    provider: openai-codex
    model: gpt-5.5
    timeout: 300
```

Skill patched:
- Skill: `hermes-agent`
- Added troubleshooting section for Codex + Gemini compression 400.
- Added instruction to pin compression to `openai-codex` + `gpt-5.5` for Scott's budget hierarchy; warn before using OpenRouter.

Verification already performed:
```text
resolved_provider: openai-codex
resolved_model: gpt-5.5
final_model: gpt-5.5
base_host: chatgpt.com
client_ok: True
py_compile_ok
```

Rollback command:
```bash
cp /home/chien/.hermes/config.yaml.bak_aux_compression_20260513_192915 /home/chien/.hermes/config.yaml
```

## Pending / next discussion
Scott asks whether running Telegram `/restart` will make 小馬 forget prior conversation. Answer:
- `/restart` restarts the gateway process to reload config; it is not `/new` or `/clear`.
- Hermes sessions are persisted; normal restart should not erase the conversation/session.
- However, restart can briefly disconnect the bot; after it comes back, continue in the same Telegram chat.
- To be extra safe, this handoff file records the key context.

Important caution:
- Do NOT tell Scott to use `/new` or `/clear` if he wants to preserve context.
- If context seems lost after restart, read this handoff file and/or search sessions for `gemini-3-flash-preview` / `auxiliary compression` / `config.yaml.bak_aux_compression_20260513_192915`.
